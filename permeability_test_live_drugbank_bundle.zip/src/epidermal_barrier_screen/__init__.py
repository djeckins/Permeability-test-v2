"""Epidermal barrier screening package."""
